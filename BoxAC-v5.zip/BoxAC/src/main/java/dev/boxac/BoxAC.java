package dev.boxac;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Llama;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class BoxAC extends JavaPlugin {

    private Settings settings = new Settings();
    private ViolationLog violations;
    private FreezeManager freeze;
    private CombatListener combat;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();

        violations = new ViolationLog(this);
        freeze = new FreezeManager(this);
        combat = new CombatListener(this, freeze);

        getServer().getPluginManager().registerEvents(combat, this);
        getServer().getPluginManager().registerEvents(new FreezeListener(this, freeze), this);
        getServer().getPluginManager().registerEvents(new BreakListener(this, combat, freeze), this);

        Commands cmds = new Commands(this, freeze);
        for (String name : List.of("freeze", "unfreeze", "boxac")) {
            var c = getCommand(name);
            if (c != null) {
                c.setExecutor(cmds);
                c.setTabCompleter(cmds);
            }
        }

        // Her tick hitbox gecmisi
        getServer().getScheduler().runTaskTimer(this, combat::tick, 1L, 1L);

        getLogger().info("BoxAC acildi [surum 1.0.5: debug, lama, kontrol alani, ritim]. Dondurulmus oyuncu sayisi: " + freeze.all().size());
    }

    @Override
    public void onDisable() {
        if (freeze != null) freeze.cleanup();
    }

    /** Kontrol alani ayarliysa konumunu dondurur, yoksa null. */
    public Location controlLocation() {
        FileConfiguration c = getConfig();
        if (!c.getBoolean("control-area.enabled", false)) return null;
        World w = Bukkit.getWorld(c.getString("control-area.world", ""));
        if (w == null) return null;
        return new Location(w, c.getDouble("control-area.x"), c.getDouble("control-area.y"), c.getDouble("control-area.z"),
                (float) c.getDouble("control-area.yaw"), (float) c.getDouble("control-area.pitch"));
    }

    /** Kontrol alanini verilen konuma ayarlar ve config.yml'ye yazar. */
    public void setControlLocation(Location l) {
        FileConfiguration c = getConfig();
        c.set("control-area.enabled", true);
        c.set("control-area.world", l.getWorld().getName());
        c.set("control-area.x", l.getX());
        c.set("control-area.y", l.getY());
        c.set("control-area.z", l.getZ());
        c.set("control-area.yaw", (double) l.getYaw());
        c.set("control-area.pitch", (double) l.getPitch());
        saveConfig();
    }

    public void reloadAll() {
        reloadConfig();
        loadSettings();
    }

    /** Otomatik dondurmayi acar/kapatir ve config.yml'ye yazar. */
    public void setAutoFreeze(boolean on) {
        settings.autoFreeze = on;
        getConfig().set("auto-freeze", on);
        saveConfig();
    }

    /** Debug modunu acar/kapatir ve config.yml'ye yazar. */
    public void setDebug(boolean on) {
        settings.debug = on;
        getConfig().set("debug", on);
        saveConfig();
    }

    public Settings settings() {
        return settings;
    }

    public ViolationLog violations() {
        return violations;
    }

    private void loadSettings() {
        FileConfiguration c = getConfig();
        Settings s = new Settings();
        s.autoFreeze = c.getBoolean("auto-freeze", s.autoFreeze);
        s.windowSeconds = c.getInt("window-seconds", s.windowSeconds);
        s.maxLogs = c.getInt("max-logs", s.maxLogs);
        s.debug = c.getBoolean("debug", s.debug);

        s.maxPingMs = c.getInt("skip.max-ping", s.maxPingMs);
        s.minTps = c.getDouble("skip.min-tps", s.minTps);
        s.skipTicksAfterTeleport = c.getInt("skip.ticks-after-teleport", s.skipTicksAfterTeleport);
        s.maxLagTicks = c.getInt("lag.max-ticks", s.maxLagTicks);

        s.reachMax = c.getDouble("reach.max", s.reachMax);
        s.reachTolerance = c.getDouble("reach.tolerance", s.reachTolerance);
        s.hitboxExpand = c.getDouble("hitbox.expand", s.hitboxExpand);
        s.wallEnabled = c.getBoolean("wall.enabled", s.wallEnabled);
        s.wallSlack = c.getDouble("wall.slack", s.wallSlack);
        s.multiMaxTickGap = c.getInt("multi.max-tick-gap", s.multiMaxTickGap);
        s.silentSnapAngle = c.getDouble("silent-aim.snap-angle", s.silentSnapAngle);
        s.silentReturnAngle = c.getDouble("silent-aim.return-angle", s.silentReturnAngle);

        s.fastBreakEnabled = c.getBoolean("fastbreak.enabled", s.fastBreakEnabled);
        s.fastBreakMinRatio = c.getDouble("fastbreak.min-ratio", s.fastBreakMinRatio);
        s.fastBreakToleranceTicks = c.getInt("fastbreak.tolerance-ticks", s.fastBreakToleranceTicks);

        s.elytraEnabled = c.getBoolean("elytra.enabled", s.elytraEnabled);
        s.glideRecentTicks = c.getInt("elytra.recent-glide-ticks", s.glideRecentTicks);
        s.lockWindowTicks = c.getInt("elytra.lock.window-ticks", s.lockWindowTicks);
        s.lockMaxError = c.getDouble("elytra.lock.max-error", s.lockMaxError);
        s.lockMinTargetSpeed = c.getDouble("elytra.lock.min-target-speed", s.lockMinTargetSpeed);
        s.lockMinSamples = c.getInt("elytra.lock.min-samples", s.lockMinSamples);
        s.lockMinRatio = c.getDouble("elytra.lock.min-ratio", s.lockMinRatio);
        s.snapAngle = c.getDouble("elytra.snap.angle", s.snapAngle);
        s.snapMaxError = c.getDouble("elytra.snap.max-error", s.snapMaxError);
        s.fireworkWindowTicks = c.getInt("elytra.firework.window-ticks", s.fireworkWindowTicks);
        s.perfectMaxError = c.getDouble("elytra.perfect.max-error", s.perfectMaxError);
        s.perfectMinSpeed = c.getDouble("elytra.perfect.min-speed", s.perfectMinSpeed);
        s.rhythmMinBoosts = c.getInt("elytra.rhythm.min-boosts", s.rhythmMinBoosts);
        s.rhythmMinInterval = c.getInt("elytra.rhythm.min-interval", s.rhythmMinInterval);
        s.rhythmMaxSpread = c.getInt("elytra.rhythm.max-spread", s.rhythmMaxSpread);
        s.relaxStep = c.getDouble("elytra.adaptive.step", s.relaxStep);
        s.relaxMaxSteps = c.getInt("elytra.adaptive.max-steps", s.relaxMaxSteps);
        s.slotSwapEnabled = c.getBoolean("elytra.slotswap.enabled", s.slotSwapEnabled);
        s.slotSwapMaxTickGap = c.getInt("elytra.slotswap.max-tick-gap", s.slotSwapMaxTickGap);

        this.settings = s;
    }

    /** Eksen hizalı kutu (hitbox). Bukkit'e bağımlı değil, o yüzden tek başına test edilebilir. */
    public record Box(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {

        public Box expand(double d) {
            return new Box(minX - d, minY - d, minZ - d, maxX + d, maxY + d, maxZ + d);
        }
    }

    /** Saldırganın bir hareket paketindeki durumu. (ex, ey, ez) = göz konumu. */
    public record Sample(long tick, double ex, double ey, double ez, double yaw, double pitch, boolean gliding) {
    }

    /** Bir oyuncunun belirli bir tick'teki hitbox'ı (lag telafisi için geçmiş). */
    public record Snap(long tick, Box box) {
    }

    /** Bir kontrolün bulgusu. */
    public record Finding(String check, String detail) {
        @Override
        public String toString() {
            return check + "(" + detail + ")";
        }
    }

    /** Kayan zaman penceresinde log sayar. Örn: son 60 sn içinde kaç log düştü? */
    public static final class ViolationWindow {

        private final ArrayDeque<Long> times = new ArrayDeque<>();

        /** Yeni log ekler, penceredeki toplam log sayısını döndürür. */
        public int addAndCount(long nowMs, long windowMs) {
            prune(nowMs, windowMs);
            times.addLast(nowMs);
            return times.size();
        }

        public int count(long nowMs, long windowMs) {
            prune(nowMs, windowMs);
            return times.size();
        }

        public void clear() {
            times.clear();
        }

        private void prune(long nowMs, long windowMs) {
            while (!times.isEmpty() && nowMs - times.peekFirst() > windowMs) {
                times.removeFirst();
            }
        }
    }

    /** Tüm eşikler. Değerler config.yml'den doldurulur (BoxAC.loadSettings). */
    public static final class Settings {

        // --- genel ---
        public boolean autoFreeze = true;
        public int windowSeconds = 60;
        public int maxLogs = 5;            // pencere içinde bundan FAZLA log olursa dondur
        public boolean debug = false;

        // --- analizin atlanacağı durumlar ---
        public int maxPingMs = 600;
        public double minTps = 17.0;
        public int skipTicksAfterTeleport = 40;

        // --- lag telafisi ---
        public int maxLagTicks = 10;

        // --- killaura ---
        public double reachMax = 3.0;
        public double reachTolerance = 0.35;
        public double hitboxExpand = 0.2;
        public double hitboxMaxRange = 8.0;
        public boolean wallEnabled = true;
        public double wallSlack = 0.3;
        public int multiMaxTickGap = 0;
        public double silentSnapAngle = 45;
        public double silentReturnAngle = 15;

        // --- fastbreak ---
        public boolean fastBreakEnabled = true;
        public double fastBreakMinRatio = 0.75;
        public int fastBreakToleranceTicks = 2;

        // --- elytra target ---
        public boolean elytraEnabled = true;
        public int glideRecentTicks = 5;
        public int lockWindowTicks = 12;
        public double lockMaxError = 0.6;
        public double lockMinTargetSpeed = 1.5;
        public int lockMinSamples = 6;
        public double lockMinRatio = 0.7;
        public double snapAngle = 60;
        public double snapMaxError = 1.5;
        public int fireworkWindowTicks = 3;

        // --- elytra: ek katmanlar ---
        public double perfectMaxError = 0.4;     // hizli ucusta vurus aninda hedef merkezine en fazla bu kadar sapma
        public double perfectMinSpeed = 0.8;     // blok/tick
        public int rhythmMinBoosts = 4;          // fisek araligi ayni mi diye bakilacak fisek sayisi
        public int rhythmMinInterval = 8;        // tick (basili tutma 4 tick'tir, o sayilmaz)
        public int rhythmMaxSpread = 1;          // araliklar arasi en fazla fark (tick)
        public double relaxStep = 0.25;          // supheli oyuncuda esikler her log icin bu kadar gevser
        public int relaxMaxSteps = 4;

        // --- elytra: ayni tick'te slot degisip geri donme (fisek <-> silah hilesi imzasi) ---
        public boolean slotSwapEnabled = true;
        public int slotSwapMaxTickGap = 0;       // 0 = ayni tick
    }

    /** Tek bir vuruşun analiz için gereken tüm verisi. */
    public static final class AttackContext {

        public long attackTick;

        /** Saldırı anındaki göz konumu ve rotasyon. */
        public double eyeX, eyeY, eyeZ;
        public double yaw, pitch;

        /** Analiz anındaki (saldırıdan ~2 tick sonra) güncel rotasyon. */
        public double yawAfter, pitchAfter;

        public boolean gliding;
        public boolean recentlyGliding;
        public int pingMs;

        /** Oyuncunun penceredeki log sayisi: supheli oyuncuya karsi esikler gevsetilir. */
        public int suspicion;

        /** Önceki vuruş FARKLI bir hedefeydi ve kaç tick önceydi? (-1 = yok) */
        public int otherTargetTickGap = -1;

        public List<Sample> samples = new ArrayList<>();         // saldırganın hareket örnekleri (eski -> yeni)
        public List<Snap> targetHistory = new ArrayList<>();      // hedefin hitbox geçmişi (eski -> yeni)
        public List<Long> slotChangeTicks = new ArrayList<>();
        public List<Long> boostTicks = new ArrayList<>();

        /** null değilse analiz metrikleri (debug) buraya yazılır. */
        public List<String> metrics;
    }

    /** Küçük vektör/geometri yardımcıları. Minecraft yaw/pitch düzenini kullanır. */
    public static final class Geo {

        private Geo() {
        }

        /** Minecraft yaw/pitch (derece) -> bakış yönü. Bukkit'in Location#getDirection ile aynı. */
        public static double[] dir(double yawDeg, double pitchDeg) {
            double yaw = Math.toRadians(yawDeg);
            double pitch = Math.toRadians(pitchDeg);
            double xz = Math.cos(pitch);
            return new double[]{-xz * Math.sin(yaw), -Math.sin(pitch), xz * Math.cos(yaw)};
        }

        /** İki yön arasındaki açı (derece). */
        public static double angle(double[] a, double[] b) {
            double la = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
            double lb = Math.sqrt(b[0] * b[0] + b[1] * b[1] + b[2] * b[2]);
            if (la < 1e-9 || lb < 1e-9) return 0;
            double c = (a[0] * b[0] + a[1] * b[1] + a[2] * b[2]) / (la * lb);
            c = Math.max(-1, Math.min(1, c));
            return Math.toDegrees(Math.acos(c));
        }

        /** Noktadan kutunun en yakın noktasına uzaklık (içindeyse 0). */
        public static double distance(Box b, double px, double py, double pz) {
            double dx = Math.max(Math.max(b.minX() - px, 0), px - b.maxX());
            double dy = Math.max(Math.max(b.minY() - py, 0), py - b.maxY());
            double dz = Math.max(Math.max(b.minZ() - pz, 0), pz - b.maxZ());
            return Math.sqrt(dx * dx + dy * dy + dz * dz);
        }

        /** (ox,oy,oz) noktasından kutunun merkezine giden vektör. */
        public static double[] toCenter(Box b, double ox, double oy, double oz) {
            return new double[]{
                    (b.minX() + b.maxX()) / 2 - ox,
                    (b.minY() + b.maxY()) / 2 - oy,
                    (b.minZ() + b.maxZ()) / 2 - oz
            };
        }

        /** Işın (başlangıç + yön) kutuya maxDist içinde değiyor mu? (slab yöntemi) */
        public static boolean rayHits(Box b, double ox, double oy, double oz, double[] d, double maxDist) {
            double tMin = 0;
            double tMax = maxDist;
            double[] o = {ox, oy, oz};
            double[] lo = {b.minX(), b.minY(), b.minZ()};
            double[] hi = {b.maxX(), b.maxY(), b.maxZ()};
            for (int i = 0; i < 3; i++) {
                if (Math.abs(d[i]) < 1e-12) {
                    if (o[i] < lo[i] || o[i] > hi[i]) return false;
                } else {
                    double t1 = (lo[i] - o[i]) / d[i];
                    double t2 = (hi[i] - o[i]) / d[i];
                    if (t1 > t2) {
                        double tmp = t1;
                        t1 = t2;
                        t2 = tmp;
                    }
                    tMin = Math.max(tMin, t1);
                    tMax = Math.min(tMax, t2);
                    if (tMin > tMax) return false;
                }
            }
            return true;
        }
    }

    /**
     * Bir vuruşu analiz eder ve şüpheli bulguları döndürür. Bukkit'e bağımlı değil.
     *
     * Genel mantık: sunucu, saldırganın istemcisinin hedefi nerede GÖRDÜĞÜNÜ bilemez (ping + interpolasyon).
     * Bu yüzden hedefin son birkaç tick'lik konum geçmişinin hepsini "olabilir" sayıp en lehe olanı seçeriz.
     * Bulgu ancak hiçbir olasılıkla açıklanamıyorsa çıkar.
     */
    public static final class Analyzer {

        /** İstemci, hedefi sunucudan bu kadar tick eski görebilir (interpolasyon payı). */
        private static final int INTERP_TICKS = 3;

        private Analyzer() {
        }

        public static List<Finding> analyze(AttackContext c, Settings s) {
            List<Finding> out = new ArrayList<>();
            List<Box> boxes = candidateBoxes(c, s);
            if (boxes.isEmpty()) return out;

            reach(c, boxes, s, out);
            hitbox(c, boxes, s, out);
            silentAim(c, boxes, s, out);

            if (c.otherTargetTickGap >= 0 && c.otherTargetTickGap <= s.multiMaxTickGap) {
                out.add(new Finding("MultiAura", "ayni tick'te 2 farkli hedefe vurus"));
            }

            if (s.elytraEnabled && (c.gliding || c.recentlyGliding)) {
                elytraLock(c, s, out);
                elytraSnap(c, boxes, s, out);
                autoFirework(c, s, out);
                elytraPerfectAim(c, boxes, s, out);
                fireworkRhythm(c, s, out);
            }
            return out;
        }

        // ------------------------------------------------------------------ yardımcılar

        static int lagTicks(AttackContext c, Settings s) {
            return Math.min(s.maxLagTicks, (int) Math.ceil(Math.max(0, c.pingMs) / 50.0));
        }

        /** Lag telafisi: saldırganın görmüş olabileceği tüm hedef hitbox'ları. */
        public static List<Box> candidateBoxes(AttackContext c, Settings s) {
            int lag = lagTicks(c, s);
            long from = c.attackTick - lag - INTERP_TICKS;
            List<Box> r = new ArrayList<>();
            for (Snap sn : c.targetHistory) {
                if (sn.tick() >= from && sn.tick() <= c.attackTick) r.add(sn.box());
            }
            return r;
        }

        /** Saldırının yapılmış olabileceği rotasyonlar (saldırı anı, sonrası ve çevresindeki örnekler). */
        private static List<double[]> rotations(AttackContext c) {
            List<double[]> r = new ArrayList<>();
            r.add(new double[]{c.yaw, c.pitch});
            r.add(new double[]{c.yawAfter, c.pitchAfter});
            for (Sample sm : c.samples) {
                if (sm.tick() >= c.attackTick - 1 && sm.tick() <= c.attackTick + 2) {
                    r.add(new double[]{sm.yaw(), sm.pitch()});
                }
            }
            return r;
        }

        private static void metric(AttackContext c, String fmt, Object... args) {
            if (c.metrics != null) c.metrics.add(String.format(Locale.ROOT, fmt, args));
        }

        private static String f(String fmt, Object... args) {
            return String.format(Locale.ROOT, fmt, args);
        }

        // ------------------------------------------------------------------ killaura

        private static void reach(AttackContext c, List<Box> boxes, Settings s, List<Finding> out) {
            double min = Double.MAX_VALUE;
            for (Box b : boxes) min = Math.min(min, Geo.distance(b, c.eyeX, c.eyeY, c.eyeZ));
            double limit = s.reachMax + s.reachTolerance;
            metric(c, "reach=%.2f", min);
            if (min > limit) {
                out.add(new Finding("Reach", f("%.2f blok, limit %.2f", min, limit)));
            }
        }

        private static void hitbox(AttackContext c, List<Box> boxes, Settings s, List<Finding> out) {
            double bestErr = Double.MAX_VALUE;
            for (double[] rot : rotations(c)) {
                double[] d = Geo.dir(rot[0], rot[1]);
                for (Box b : boxes) {
                    if (Geo.rayHits(b.expand(s.hitboxExpand), c.eyeX, c.eyeY, c.eyeZ, d, s.hitboxMaxRange)) {
                        metric(c, "hitbox=ok");
                        return;
                    }
                    bestErr = Math.min(bestErr, Geo.angle(d, Geo.toCenter(b, c.eyeX, c.eyeY, c.eyeZ)));
                }
            }
            metric(c, "hitbox=ISKA(%.1f)", bestErr);
            out.add(new Finding("Hitbox", f("hedefe %.1f derece sapma, isabet yok", bestErr)));
        }

        /**
         * Silent aura imzası: rotasyon tek adımda hedefe atlıyor, vuruyor, sonra neredeyse eski yöne geri dönüyor.
         */
        private static void silentAim(AttackContext c, List<Box> boxes, Settings s, List<Finding> out) {
            List<Sample> w = new ArrayList<>();
            for (Sample sm : c.samples) {
                if (sm.tick() >= c.attackTick - 3 && sm.tick() <= c.attackTick + 3) w.add(sm);
            }
            for (int j = 1; j + 1 < w.size(); j++) {
                Sample a = w.get(j - 1);
                Sample m = w.get(j);
                Sample z = w.get(j + 1);
                double[] da = Geo.dir(a.yaw(), a.pitch());
                double[] dm = Geo.dir(m.yaw(), m.pitch());
                double[] dz = Geo.dir(z.yaw(), z.pitch());
                double in = Geo.angle(da, dm);
                double back = Geo.angle(dm, dz);
                double net = Geo.angle(da, dz);
                if (in >= s.silentSnapAngle && back >= s.silentSnapAngle && net <= s.silentReturnAngle
                        && aimsAt(c, dm, boxes, s)) {
                    out.add(new Finding("SilentAim", f("%.0f derece atla, vur, %.0f derece geri dondu", in, back)));
                    return;
                }
            }
        }

        private static boolean aimsAt(AttackContext c, double[] dir, List<Box> boxes, Settings s) {
            for (Box b : boxes) {
                if (Geo.rayHits(b.expand(s.hitboxExpand), c.eyeX, c.eyeY, c.eyeZ, dir, s.hitboxMaxRange)) return true;
            }
            return false;
        }

        // ------------------------------------------------------------------ elytra target

        /**
         * Robot kilidi: hedef ekranda hızlıca kayarken (kendi uçuşun + hedefin hareketi) nişan, hedef merkezinden
         * neredeyse hiç sapmıyorsa şüpheli. Hedef durağan/ortada ise sayılmaz (düz uçup vuran oyuncuyu yakalamasın).
         */
        private static void elytraLock(AttackContext c, Settings s, List<Finding> out) {
            int lag = lagTicks(c, s);
            int steps = Math.min(Math.max(c.suspicion, 0), s.relaxMaxSteps);
            double maxErr = s.lockMaxError * (1 + s.relaxStep * steps);
            double minRatio = Math.max(0.4, s.lockMinRatio - 0.05 * steps);
            List<Sample> win = new ArrayList<>();
            for (Sample sm : c.samples) {
                if (sm.tick() >= c.attackTick - s.lockWindowTicks && sm.tick() <= c.attackTick && sm.gliding()) {
                    win.add(sm);
                }
            }
            if (win.size() < s.lockMinSamples + 1) {
                metric(c, "lock=ornek-yetersiz(%d)", win.size());
                return;
            }

            int tight = 0;
            int moving = 0;
            double sumErr = 0;
            double sumSpeed = 0;
            double[] prevIdeal = null;
            long prevTick = -1;

            for (Sample sm : win) {
                Snap ref = nearest(c.targetHistory, sm.tick() - lag - 1);
                if (ref == null) {
                    prevIdeal = null;
                    continue;
                }
                double[] ideal = Geo.toCenter(ref.box(), sm.ex(), sm.ey(), sm.ez());
                double speed = -1;
                long gap = sm.tick() - prevTick;
                if (prevIdeal != null && gap >= 1 && gap <= 2) {
                    speed = Geo.angle(prevIdeal, ideal) / gap;   // derece / tick
                }
                prevIdeal = ideal;
                prevTick = sm.tick();
                if (speed < s.lockMinTargetSpeed) continue;

                double[] look = Geo.dir(sm.yaw(), sm.pitch());
                double best = Double.MAX_VALUE;
                for (Snap sn : c.targetHistory) {
                    if (sn.tick() < sm.tick() - lag - INTERP_TICKS || sn.tick() > sm.tick() - lag + 1) continue;
                    best = Math.min(best, Geo.angle(look, Geo.toCenter(sn.box(), sm.ex(), sm.ey(), sm.ez())));
                }
                if (best == Double.MAX_VALUE) continue;

                moving++;
                sumErr += best;
                sumSpeed += speed;
                if (best <= maxErr) tight++;
            }

            if (moving > 0) {
                metric(c, "lock=%d/%d hata=%.2f hiz=%.1f", tight, moving, sumErr / moving, sumSpeed / moving);
            } else {
                metric(c, "lock=hedef-durgun");
            }
            if (tight >= s.lockMinSamples && (double) tight / moving >= minRatio) {
                out.add(new Finding("ElytraLock",
                        f("%d/%d tick'te hata < %.1f derece, ort. hedef hizi %.1f derece/tick",
                                tight, moving, maxErr, sumSpeed / moving)));
            }
        }

        /** Tek tick'te büyük bir dönüş + hedef merkezine tam isabet. */
        private static void elytraSnap(AttackContext c, List<Box> boxes, Settings s, List<Finding> out) {
            List<Sample> w = new ArrayList<>();
            for (Sample sm : c.samples) {
                if (sm.tick() >= c.attackTick - 3 && sm.tick() <= c.attackTick + 2) w.add(sm);
            }
            for (int j = 1; j < w.size(); j++) {
                Sample prev = w.get(j - 1);
                Sample cur = w.get(j);
                double[] dCur = Geo.dir(cur.yaw(), cur.pitch());
                double turn = Geo.angle(Geo.dir(prev.yaw(), prev.pitch()), dCur);
                if (turn < s.snapAngle) continue;
                double err = Double.MAX_VALUE;
                for (Box b : boxes) {
                    err = Math.min(err, Geo.angle(dCur, Geo.toCenter(b, c.eyeX, c.eyeY, c.eyeZ)));
                }
                if (err <= s.snapMaxError * (1 + s.relaxStep * Math.min(Math.max(c.suspicion, 0), s.relaxMaxSteps))) {
                    out.add(new Finding("ElytraSnap", f("%.0f derece donus, hedefe %.1f derece hata", turn, err)));
                    return;
                }
            }
        }

        /** Slot değiştir + fişek + slot geri + vuruş, hepsi birkaç tick içinde. */
        private static void autoFirework(AttackContext c, Settings s, List<Finding> out) {
            long from = c.attackTick - s.fireworkWindowTicks;
            boolean boost = false;
            int swaps = 0;
            for (long t : c.boostTicks) {
                if (t >= from && t <= c.attackTick) boost = true;
            }
            for (long t : c.slotChangeTicks) {
                if (t >= from && t <= c.attackTick) swaps++;
            }
            metric(c, "fisek=%s slot=%d", boost, swaps);
            if (boost && swaps >= 2) {
                out.add(new Finding("AutoFirework",
                        f("%d tick icinde slot degisimi x%d + fisek + vurus", s.fireworkWindowTicks, swaps)));
            }
        }

        /** Hizli ucarken vurus aninda nisan hedef merkezinden neredeyse hic sapmiyorsa: insan icin cok zor. */
        private static void elytraPerfectAim(AttackContext c, List<Box> boxes, Settings s, List<Finding> out) {
            double speed = attackerSpeed(c);
            if (speed < s.perfectMinSpeed) {
                metric(c, "perfect=yavas(%.2f)", speed);
                return;
            }
            int steps = Math.min(Math.max(c.suspicion, 0), s.relaxMaxSteps);
            double limit = s.perfectMaxError * (1 + s.relaxStep * steps);
            double best = Double.MAX_VALUE;
            double[][] rots = {{c.yaw, c.pitch}, {c.yawAfter, c.pitchAfter}};
            for (double[] rot : rots) {
                double[] d = Geo.dir(rot[0], rot[1]);
                for (Box b : boxes) {
                    best = Math.min(best, Geo.angle(d, Geo.toCenter(b, c.eyeX, c.eyeY, c.eyeZ)));
                }
            }
            metric(c, "perfect=%.2f hiz=%.2f", best, speed);
            if (best <= limit) {
                out.add(new Finding("ElytraPerfectAim",
                        f("hizli ucusta (%.1f blok/tick) hedef merkezine %.2f derece", speed, best)));
            }
        }

        /** Son iki hareket ornegine gore saldirganin hizi (blok/tick). */
        private static double attackerSpeed(AttackContext c) {
            Sample last = null;
            for (int i = c.samples.size() - 1; i >= 0; i--) {
                Sample sm = c.samples.get(i);
                if (sm.tick() > c.attackTick) continue;
                if (last == null) {
                    last = sm;
                    continue;
                }
                long gap = last.tick() - sm.tick();
                if (gap < 1) continue;
                if (gap > 2) return 0;
                double dx = last.ex() - sm.ex();
                double dy = last.ey() - sm.ey();
                double dz = last.ez() - sm.ez();
                return Math.sqrt(dx * dx + dy * dy + dz * dz) / gap;
            }
            return 0;
        }

        /** Fisekler hep ayni aralikla (ornegin her 10 tick) atiliyorsa makro/hile. Basili tutma (4 tick) sayilmaz. */
        private static void fireworkRhythm(AttackContext c, Settings s, List<Finding> out) {
            List<Long> b = new ArrayList<>();
            for (long t : c.boostTicks) {
                if (t <= c.attackTick && (b.isEmpty() || t != b.get(b.size() - 1))) b.add(t);
            }
            if (b.size() < s.rhythmMinBoosts) return;
            List<Long> last = b.subList(b.size() - s.rhythmMinBoosts, b.size());
            long min = Long.MAX_VALUE;
            long max = Long.MIN_VALUE;
            for (int i = 1; i < last.size(); i++) {
                long d = last.get(i) - last.get(i - 1);
                if (d < s.rhythmMinInterval || d > 100) return;
                min = Math.min(min, d);
                max = Math.max(max, d);
            }
            metric(c, "ritim=%d-%d", min, max);
            if (max - min <= s.rhythmMaxSpread) {
                out.add(new Finding("FireworkRhythm",
                        f("son %d fisek %d-%d tick arayla (insan duzensiz atar)", s.rhythmMinBoosts, min, max)));
            }
        }

        private static Snap nearest(List<Snap> history, long tick) {
            Snap best = null;
            long bestDiff = Long.MAX_VALUE;
            for (Snap sn : history) {
                long d = Math.abs(sn.tick() - tick);
                if (d < bestDiff) {
                    bestDiff = d;
                    best = sn;
                }
            }
            return (best != null && bestDiff <= 2) ? best : null;
        }
    }

    /** Dondurulmus oyunculari tutar. Liste diske yazilir, sunucu yeniden baslasa da kalir. */
    public static final class FreezeManager {

        private final BoxAC plugin;
        private final Set<UUID> frozen = new HashSet<>();
        private final File file;
        private final MiniMessage mm = MiniMessage.miniMessage();
        private final List<Llama> showLlamas = new ArrayList<>();

        public FreezeManager(BoxAC plugin) {
            this.plugin = plugin;
            this.file = new File(plugin.getDataFolder(), "frozen.yml");
            load();
        }

        public boolean isFrozen(UUID id) {
            return frozen.contains(id);
        }

        public Set<UUID> all() {
            return Set.copyOf(frozen);
        }

        public void freeze(Player p) {
            if (!frozen.add(p.getUniqueId())) return;
            save();
            apply(p);
            punishShow(p);
        }

        public void unfreeze(UUID id) {
            if (!frozen.remove(id)) return;
            save();
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.setWalkSpeed(0.2f);
                p.setFlySpeed(0.1f);
                p.clearTitle();
                p.sendMessage(mm.deserialize(plugin.getConfig().getString("messages.unfrozen", "<green>Dondurman kaldirildi.")));
            }
        }

        /** Oyuncuya dondurma etkilerini ve mesajlari uygular (giriste de tekrar cagrilir). */
        public void apply(Player p) {
            p.setWalkSpeed(0f);
            p.setFlySpeed(0f);
            if (p.isGliding()) p.setGliding(false);

            String t = plugin.getConfig().getString("messages.title", "<red>Hile kullandigin icin mutlu musun oyuncu?");
            String st = plugin.getConfig().getString("messages.subtitle", "");
            p.showTitle(Title.title(mm.deserialize(t), mm.deserialize(st),
                    Title.Times.times(Duration.ZERO, Duration.ofDays(1), Duration.ZERO)));
            List<String> lines = plugin.getConfig().getStringList("messages.chat");
            for (String l : lines) p.sendMessage(mm.deserialize(l));
        }

        /** Etrafinda lamalar cikip tukurur; sure bitince oyuncu kontrol alanina cekilir (donuk kalir). */
        private void punishShow(Player p) {
            FileConfiguration cfg = plugin.getConfig();
            int seconds = Math.max(0, cfg.getInt("llama-show.seconds", 2));
            int count = Math.max(0, cfg.getInt("llama-show.count", 4));
            List<Llama> mine = new ArrayList<>();
            if (cfg.getBoolean("llama-show.enabled", true) && count > 0 && seconds > 0) {
                Location base = p.getLocation();
                for (int i = 0; i < count; i++) {
                    double a = 2 * Math.PI * i / count;
                    Location spot = base.clone().add(Math.cos(a) * 2.5, 0, Math.sin(a) * 2.5);
                    Llama llama = base.getWorld().spawn(spot, Llama.class, ll -> ll.setPersistent(false));
                    mine.add(llama);
                    showLlamas.add(llama);
                }
            }
            UUID id = p.getUniqueId();
            BukkitTask aim = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
                Player pl = Bukkit.getPlayer(id);
                for (Llama ll : mine) {
                    if (pl != null && ll.isValid()) ll.setTarget(pl);
                }
            }, 1L, 10L);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                aim.cancel();
                for (Llama ll : mine) {
                    ll.remove();
                    showLlamas.remove(ll);
                }
                Player pl = Bukkit.getPlayer(id);
                Location control = plugin.controlLocation();
                if (pl != null && control != null && isFrozen(id)) pl.teleport(control);
            }, Math.max(1L, seconds * 20L));
        }

        /** Eklenti kapanirken kalan lamalari siler. */
        public void cleanup() {
            for (Llama ll : new ArrayList<>(showLlamas)) ll.remove();
            showLlamas.clear();
        }

        public Component parse(String s) {
            return mm.deserialize(s);
        }

        private void load() {
            if (!file.exists()) return;
            YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
            for (String s : y.getStringList("frozen")) {
                try {
                    frozen.add(UUID.fromString(s));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        private void save() {
            YamlConfiguration y = new YamlConfiguration();
            y.set("frozen", frozen.stream().map(UUID::toString).toList());
            try {
                plugin.getDataFolder().mkdirs();
                y.save(file);
            } catch (IOException e) {
                plugin.getLogger().warning("frozen.yml yazilamadi: " + e.getMessage());
            }
        }
    }

    /** Loglari plugins/BoxAC/violations.log dosyasina yazar. */
    public static final class ViolationLog {

        private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        private final BoxAC plugin;
        private final File file;

        public ViolationLog(BoxAC plugin) {
            this.plugin = plugin;
            this.file = new File(plugin.getDataFolder(), "violations.log");
        }

        public void record(String player, List<Finding> findings, int count, int ping) {
            String line = "[" + LocalDateTime.now().format(FMT) + "] " + player
                    + " ping=" + ping + "ms sayac=" + count + " " + findings;
            plugin.getLogger().info(line);
            plugin.getDataFolder().mkdirs();
            try (PrintWriter w = new PrintWriter(new FileWriter(file, true))) {
                w.println(line);
            } catch (IOException e) {
                plugin.getLogger().warning("violations.log yazilamadi: " + e.getMessage());
            }
        }
    }

    /**
     * Oyuncu verisini toplar, vurus aninda analiz eder, log dusurur, esik asilirsa dondurur.
     * Hepsi ana thread'de calisir (Bukkit olaylari), ayri thread yok.
     */
    public static final class CombatListener implements Listener {

        private static final int HISTORY_TICKS = 40;

        private final BoxAC plugin;
        private final FreezeManager freeze;
        private final Map<UUID, Data> data = new HashMap<>();

        /** Oyuncu basina toplanan veri. */
        private static final class Data {
            final ArrayDeque<Sample> samples = new ArrayDeque<>();
            final ArrayDeque<Snap> boxes = new ArrayDeque<>();
            final ArrayDeque<Long> slotChanges = new ArrayDeque<>();
            final ArrayDeque<Long> boosts = new ArrayDeque<>();
            final ArrayDeque<int[]> slotEvents = new ArrayDeque<>();   // {tick, onceki slot, yeni slot}
            long lastSlotFlagTick = -1000;
            final ViolationWindow window = new ViolationWindow();
            long lastGlideTick = -1000;
            long ignoreUntilTick = 0;
            UUID lastTarget;
            long lastTargetTick = -1000;
            boolean wasGlidingAtJoin;
        }

        public CombatListener(BoxAC plugin, FreezeManager freeze) {
            this.plugin = plugin;
            this.freeze = freeze;
            for (Player p : Bukkit.getOnlinePlayers()) data.put(p.getUniqueId(), new Data());
        }

        private Data d(Player p) {
            return data.computeIfAbsent(p.getUniqueId(), k -> new Data());
        }

        private long now() {
            return Bukkit.getCurrentTick();
        }

        /** Debug aciksa, vurusun neden analiz edilmedigini konsola yazar. */
        private void dbg(Player attacker, String why) {
            if (plugin.settings().debug) plugin.getLogger().info("[debug] " + attacker.getName() + " analiz atlandi: " + why);
        }

        // ------------------------------------------------------------------ veri toplama

        /** Her tick tum oyuncularin hitbox gecmisini tutar (lag telafisi icin). BoxAC.onEnable'dan zamanlanir. */
        public void tick() {
            long t = now();
            for (Player p : Bukkit.getOnlinePlayers()) {
                Data dd = d(p);
                BoundingBox bb = p.getBoundingBox();
                dd.boxes.addLast(new Snap(t, new Box(bb.getMinX(), bb.getMinY(), bb.getMinZ(),
                        bb.getMaxX(), bb.getMaxY(), bb.getMaxZ())));
                while (!dd.boxes.isEmpty() && t - dd.boxes.peekFirst().tick() > HISTORY_TICKS) dd.boxes.removeFirst();
                if (p.isGliding()) dd.lastGlideTick = t;
            }
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onMove(PlayerMoveEvent e) {
            Player p = e.getPlayer();
            Location to = e.getTo();
            if (to == null) return;
            Data dd = d(p);
            long t = now();
            double eyeH = p.getEyeHeight();
            dd.samples.addLast(new Sample(t, to.getX(), to.getY() + eyeH, to.getZ(), to.getYaw(), to.getPitch(), p.isGliding()));
            while (!dd.samples.isEmpty() && t - dd.samples.peekFirst().tick() > HISTORY_TICKS) dd.samples.removeFirst();
        }

        @EventHandler(ignoreCancelled = true)
        public void onSlot(PlayerItemHeldEvent e) {
            Player p = e.getPlayer();
            Data dd = d(p);
            long t = now();
            dd.slotChanges.addLast(t);
            while (!dd.slotChanges.isEmpty() && t - dd.slotChanges.peekFirst() > HISTORY_TICKS) dd.slotChanges.removeFirst();

            dd.slotEvents.addLast(new int[]{(int) t, e.getPreviousSlot(), e.getNewSlot()});
            while (!dd.slotEvents.isEmpty() && t - dd.slotEvents.peekFirst()[0] > 4) dd.slotEvents.removeFirst();
            checkSlotSwap(p, dd, t);
        }

        /**
         * Elytra hileleri fisek ile silah arasinda ayni tick'te gecip geri doner (A -> B -> A).
         * Insan 50 ms icinde iki kez slot degistirip geri donemez. Vurus beklemeden, anlik log dusurur.
         */
        private void checkSlotSwap(Player p, Data dd, long t) {
            Settings s = plugin.settings();
            if (!s.slotSwapEnabled || !s.elytraEnabled) return;
            if (!p.isGliding() && t - dd.lastGlideTick > s.glideRecentTicks) return;
            if (p.hasPermission("boxac.bypass") || freeze.isFrozen(p.getUniqueId())) return;
            if (p.getGameMode() == org.bukkit.GameMode.CREATIVE || p.getGameMode() == org.bukkit.GameMode.SPECTATOR) return;
            if (t < dd.ignoreUntilTick || t == dd.lastSlotFlagTick) return;

            List<int[]> ev = new ArrayList<>(dd.slotEvents);
            if (ev.size() < 2) return;
            int[] b = ev.get(ev.size() - 1);
            int[] a = ev.get(ev.size() - 2);
            long gap = b[0] - a[0];
            boolean returning = a[1] == b[2] && a[1] != a[2];
            boolean triple = ev.size() >= 3 && gap == 0 && ev.get(ev.size() - 3)[0] == b[0];
            if (gap <= s.slotSwapMaxTickGap && (returning || triple)) {
                dd.lastSlotFlagTick = t;
                flag(p, List.of(new Finding("SlotSwap",
                        "ayni tick'te slot " + (a[1] + 1) + " -> " + (a[2] + 1) + " -> " + (b[2] + 1) + " (ucarken)")));
            }
        }

        /** Istege bagli: ucarken elinde fisek varken oyuncuya vurulursa hasar 0 olur. */
        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onFireworkHit(EntityDamageByEntityEvent e) {
            if (!plugin.getConfig().getBoolean("elytra.firework-hit-no-damage", false)) return;
            if (!(e.getDamager() instanceof Player a) || !(e.getEntity() instanceof Player)) return;
            if (a.isGliding() && a.getInventory().getItemInMainHand().getType() == Material.FIREWORK_ROCKET) {
                e.setDamage(0);
            }
        }

        // Hava tiklamalari Bukkit'te varsayilan olarak "iptal" sayilir; ignoreCancelled kullanilirsa fisek hic gorunmez.
        @EventHandler(priority = EventPriority.MONITOR)
        public void onInteract(PlayerInteractEvent e) {
            ItemStack it = e.getItem();
            if (it == null || it.getType() != Material.FIREWORK_ROCKET) return;
            Player p = e.getPlayer();
            if (!p.isGliding()) return;
            Data dd = d(p);
            long t = now();
            dd.boosts.addLast(t);
            while (!dd.boosts.isEmpty() && t - dd.boosts.peekFirst() > 160) dd.boosts.removeFirst();
        }

        @EventHandler(ignoreCancelled = true)
        public void onGlide(EntityToggleGlideEvent e) {
            if (e.getEntity() instanceof Player p) d(p).lastGlideTick = now();
        }

        @EventHandler
        public void onTeleport(PlayerTeleportEvent e) {
            skip(e.getPlayer());
        }

        @EventHandler
        public void onRespawn(PlayerRespawnEvent e) {
            skip(e.getPlayer());
        }

        @EventHandler
        public void onJoin(PlayerJoinEvent e) {
            Player p = e.getPlayer();
            data.put(p.getUniqueId(), new Data());
            skip(p);
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent e) {
            data.remove(e.getPlayer().getUniqueId());
        }

        private void skip(Player p) {
            d(p).ignoreUntilTick = now() + plugin.settings().skipTicksAfterTeleport;
        }

        // ------------------------------------------------------------------ analiz

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onHit(EntityDamageByEntityEvent e) {
            if (!(e.getDamager() instanceof Player attacker)) return;
            if (!(e.getEntity() instanceof Player target)) {
                dbg(attacker, "hedef oyuncu degil: " + e.getEntity().getType());
                return;
            }
            if (attacker.hasPermission("boxac.bypass")) {
                dbg(attacker, "boxac.bypass yetkisi var (LuckPerms * verdiysen bypass sayilir)");
                return;
            }
            if (freeze.isFrozen(attacker.getUniqueId())) return;

            Settings s = plugin.settings();
            Data dd = d(attacker);
            long t = now();

            // Hedefi kaydet (MultiAura icin onceki hedef bilgisi)
            int otherGap = -1;
            if (dd.lastTarget != null && !dd.lastTarget.equals(target.getUniqueId())) {
                otherGap = (int) (t - dd.lastTargetTick);
            }
            dd.lastTarget = target.getUniqueId();
            dd.lastTargetTick = t;

            // Yanlis alarmi azaltan atlamalar
            if (t < dd.ignoreUntilTick) {
                dbg(attacker, "isinlanma/giris/respawn sonrasi bekleme suresi");
                return;
            }
            if (attacker.getPing() > s.maxPingMs) {
                dbg(attacker, "ping cok yuksek: " + attacker.getPing());
                return;
            }
            if (Bukkit.getTPS()[0] < s.minTps) {
                dbg(attacker, "sunucu TPS dusuk: " + String.format("%.1f", Bukkit.getTPS()[0]));
                return;
            }
            if (attacker.getGameMode() == org.bukkit.GameMode.CREATIVE || attacker.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
                dbg(attacker, "oyun modu " + attacker.getGameMode() + " (survival/adventure olmali)");
                return;
            }

            Data td = d(target);
            AttackContext c = new AttackContext();
            c.attackTick = t;
            Location eye = attacker.getEyeLocation();
            c.eyeX = eye.getX();
            c.eyeY = eye.getY();
            c.eyeZ = eye.getZ();
            c.yaw = eye.getYaw();
            c.pitch = eye.getPitch();
            c.yawAfter = c.yaw;
            c.pitchAfter = c.pitch;
            c.gliding = attacker.isGliding();
            c.recentlyGliding = (t - dd.lastGlideTick) <= s.glideRecentTicks;
            c.pingMs = attacker.getPing();
            c.suspicion = dd.window.count(System.currentTimeMillis(), s.windowSeconds * 1000L);
            c.otherTargetTickGap = otherGap;
            c.samples = new ArrayList<>(dd.samples);
            c.targetHistory = new ArrayList<>(td.boxes);
            c.slotChangeTicks = new ArrayList<>(dd.slotChanges);
            c.boostTicks = new ArrayList<>(dd.boosts);
            if (s.debug) c.metrics = new ArrayList<>();

            // Silent aim ve snap, vurustan SONRAKI tick'lere de bakar: analizi 2 tick geciktir.
            final String name = attacker.getName();
            final UUID id = attacker.getUniqueId();
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                Player a = Bukkit.getPlayer(id);
                if (a == null || !a.isOnline()) return;
                Data cur = data.get(id);
                if (cur == null) return;
                c.samples = new ArrayList<>(cur.samples);
                Location l = a.getEyeLocation();
                c.yawAfter = l.getYaw();
                c.pitchAfter = l.getPitch();
                run(a, name, c);
            }, 2L);
        }

        private void run(Player attacker, String name, AttackContext c) {
            Settings s = plugin.settings();
            List<Finding> findings = Analyzer.analyze(c, s);

            // Duvar arkasindan vurus (Bukkit ray trace gerektirdigi icin burada)
            if (s.wallEnabled) wall(attacker, c, s, findings);

            if (c.metrics != null) {
                plugin.getLogger().info("[debug] " + name + " glide=" + c.gliding + "/" + c.recentlyGliding + " ping=" + c.pingMs + " " + String.join(" ", c.metrics)
                        + (findings.isEmpty() ? " -> temiz" : " -> " + findings));
            }
            flag(attacker, findings);
        }

        /** Oyuncuya log dusurur; esik asilirsa dondurur. Tum kontroller (vurus, kirma) buradan gecer. */
        public void flag(Player attacker, List<Finding> findings) {
            if (findings.isEmpty()) return;
            Settings s = plugin.settings();
            String name = attacker.getName();
            Data dd = d(attacker);
            long nowMs = System.currentTimeMillis();
            int count = dd.window.addAndCount(nowMs, s.windowSeconds * 1000L);
            plugin.violations().record(name, findings, count, attacker.getPing());
            alert(name, findings, count, s);

            if (s.autoFreeze && count > s.maxLogs && !freeze.isFrozen(attacker.getUniqueId())) {
                freeze.freeze(attacker);
                dd.window.clear();
                plugin.violations().record(name, List.of(new Finding("OTOMATIK-DONDURMA",
                        count + " log / " + s.windowSeconds + " sn")), count, attacker.getPing());
                alertFrozen(name, count, s);
            }
        }

        private void wall(Player attacker, AttackContext c, Settings s, List<Finding> out) {
            List<Box> boxes = Analyzer.candidateBoxes(c, s);
            if (boxes.isEmpty()) return;
            Location eye = attacker.getEyeLocation();
            double[] best = null;
            double bestDist = Double.MAX_VALUE;
            for (Box b : boxes) {
                double[] ctr = Geo.toCenter(b, c.eyeX, c.eyeY, c.eyeZ);
                double len = Math.sqrt(ctr[0] * ctr[0] + ctr[1] * ctr[1] + ctr[2] * ctr[2]);
                if (len < bestDist) {
                    bestDist = len;
                    best = ctr;
                }
            }
            if (best == null || bestDist < 0.8) return;
            Vector dir = new Vector(best[0], best[1], best[2]).normalize();
            RayTraceResult r = attacker.getWorld().rayTraceBlocks(eye, dir, bestDist - s.wallSlack);
            if (r != null && r.getHitBlock() != null && r.getHitBlock().getType().isOccluding()) {
                out.add(new Finding("Wall", "arada " + r.getHitBlock().getType().name().toLowerCase() + " blogu var"));
            }
        }

        // ------------------------------------------------------------------ uyarilar

        private void alert(String name, List<Finding> f, int count, Settings s) {
            if (!plugin.getConfig().getBoolean("alert-on-log", true)) return;
            Component msg = Component.text("[BoxAC] ", NamedTextColor.RED)
                    .append(Component.text(name, NamedTextColor.WHITE))
                    .append(Component.text(" " + f + " ", NamedTextColor.GRAY))
                    .append(Component.text("(" + count + "/" + (s.maxLogs + 1) + ")", NamedTextColor.YELLOW));
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.hasPermission("boxac.alerts")) p.sendMessage(msg);
            }
        }

        private void alertFrozen(String name, int count, Settings s) {
            String ban = plugin.getConfig().getString("ban-suggestion", "/ban %player% Hile").replace("%player%", name);
            Component msg = Component.text("[BoxAC] ", NamedTextColor.RED)
                    .append(Component.text(name + " DONDURULDU ", NamedTextColor.DARK_RED))
                    .append(Component.text("(" + s.windowSeconds + " sn'de " + count + " log) ", NamedTextColor.GRAY))
                    .append(Component.text("[Coz] ", NamedTextColor.GREEN)
                            .clickEvent(ClickEvent.suggestCommand("/unfreeze " + name))
                            .hoverEvent(HoverEvent.showText(Component.text("Dondurmayi kaldir"))))
                    .append(Component.text("[Banla]", NamedTextColor.RED)
                            .clickEvent(ClickEvent.suggestCommand(ban))
                            .hoverEvent(HoverEvent.showText(Component.text(ban))));
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.hasPermission("boxac.alerts")) p.sendMessage(msg);
            }
            plugin.getLogger().warning(name + " otomatik donduruldu (" + count + " log).");
        }
    }

    /**
     * Dondurulmus oyuncu: hareket edemez, vuramaz, vurulamaz, blok koyamaz/kiramaz, esya kullanamaz,
     * komut kullanamaz. Cozulene ya da banlanana kadar boyle kalir.
     */
    public static final class FreezeListener implements Listener {

        private final BoxAC plugin;
        private final FreezeManager freeze;

        public FreezeListener(BoxAC plugin, FreezeManager freeze) {
            this.plugin = plugin;
            this.freeze = freeze;
        }

        private boolean fz(Player p) {
            return freeze.isFrozen(p.getUniqueId());
        }

        @EventHandler(priority = EventPriority.HIGHEST)
        public void onMove(PlayerMoveEvent e) {
            if (!fz(e.getPlayer())) return;
            Location from = e.getFrom();
            Location to = e.getTo();
            if (to == null) return;
            // Bakmak serbest, konum degisemez. (Havada ise dusmesine izin vermek icin Y'ye dokunmuyoruz.)
            boolean grounded = e.getPlayer().isOnGround();
            if (from.getX() != to.getX() || from.getZ() != to.getZ() || (grounded && from.getY() < to.getY())) {
                Location back = from.clone();
                back.setYaw(to.getYaw());
                back.setPitch(to.getPitch());
                e.setTo(back);
            }
        }

        // Vuramaz
        @EventHandler(priority = EventPriority.LOWEST)
        public void onDamageDealt(EntityDamageByEntityEvent e) {
            if (e.getDamager() instanceof Player p && fz(p)) e.setCancelled(true);
            // Vurulamaz
            if (e.getEntity() instanceof Player v && fz(v)) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onAnyDamage(EntityDamageEvent e) {
            if (e.getEntity() instanceof Player v && fz(v)) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onGlide(EntityToggleGlideEvent e) {
            if (e.getEntity() instanceof Player p && fz(p) && e.isGliding()) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onBreak(BlockBreakEvent e) {
            if (fz(e.getPlayer())) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onPlace(BlockPlaceEvent e) {
            if (fz(e.getPlayer())) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onInteract(PlayerInteractEvent e) {
            if (fz(e.getPlayer())) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onInteractEntity(PlayerInteractEntityEvent e) {
            if (fz(e.getPlayer())) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onDrop(PlayerDropItemEvent e) {
            if (fz(e.getPlayer())) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onSwap(PlayerSwapHandItemsEvent e) {
            if (fz(e.getPlayer())) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onInv(InventoryClickEvent e) {
            if (e.getWhoClicked() instanceof Player p && fz(p)) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onHunger(FoodLevelChangeEvent e) {
            if (e.getEntity() instanceof Player p && fz(p)) e.setCancelled(true);
        }

        @EventHandler(priority = EventPriority.LOWEST)
        public void onCommand(PlayerCommandPreprocessEvent e) {
            Player p = e.getPlayer();
            if (!fz(p)) return;
            String cmd = e.getMessage().substring(1).split(" ")[0].toLowerCase();
            if (cmd.contains(":")) cmd = cmd.substring(cmd.indexOf(':') + 1);
            // Yetkili (boxac.freeze) donukken de /unfreeze kullanabilir (kendini test ederken kilitli kalmasin)
            if (cmd.equals("unfreeze") && p.hasPermission("boxac.freeze")) return;
            List<String> allowed = plugin.getConfig().getStringList("frozen-allowed-commands");
            if (!allowed.contains(cmd)) {
                e.setCancelled(true);
                p.sendMessage(freeze.parse("<red>Dondurulmuşken komut kullanamazsın."));
            }
        }

        // Girince dondurma tekrar uygulanir (cikip girerek kacamasin)
        @EventHandler
        public void onJoin(PlayerJoinEvent e) {
            Player p = e.getPlayer();
            if (fz(p)) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (p.isOnline() && fz(p)) freeze.apply(p);
                }, 10L);
            }
        }

        // Dondurulmus oyuncu cikarsa
        @EventHandler
        public void onQuit(PlayerQuitEvent e) {
            Player p = e.getPlayer();
            if (!fz(p)) return;
            plugin.getLogger().warning(p.getName() + " dondurulmusken oyundan cikti.");
            String ip = p.getName();
            if (p.getAddress() != null && p.getAddress().getAddress() != null) {
                ip = p.getAddress().getAddress().getHostAddress();
            }
            boolean ran = false;
            for (String cmd : plugin.getConfig().getStringList("on-quit-commands")) {
                String run = cmd.replace("%player%", p.getName()).replace("%ip%", ip);
                if (Bukkit.dispatchCommand(Bukkit.getConsoleSender(), run)) ran = true;
            }
            // Ceza komutu gercekten calistiysa donma kaydi silinir (30 gun sonra donuk donmesin)
            if (ran) freeze.unfreeze(p.getUniqueId());
        }

        // /ban, /tempban gibi bir komut donuk oyuncunun adiyla calisirsa ve oyuncu atilirsa donma kaydi silinir
        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onBanCommand(PlayerCommandPreprocessEvent e) {
            checkBan(e.getMessage());
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onBanConsole(ServerCommandEvent e) {
            checkBan(e.getCommand());
        }

        private void checkBan(String raw) {
            String[] parts = raw.trim().replaceFirst("^/", "").split("\\s+");
            if (parts.length < 2) return;
            String label = parts[0].toLowerCase();
            int colon = label.lastIndexOf(':');
            if (colon >= 0) label = label.substring(colon + 1);
            boolean isBan = false;
            for (String b : plugin.getConfig().getStringList("ban-commands")) {
                if (b.equalsIgnoreCase(label)) isBan = true;
            }
            if (!isBan) return;
            for (int i = 1; i < Math.min(parts.length, 4); i++) {
                for (UUID id : freeze.all()) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (n != null && n.equalsIgnoreCase(parts[i])) {
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (Bukkit.getPlayer(id) == null) freeze.unfreeze(id);
                        }, 3L);
                        return;
                    }
                }
            }
        }
    }

    /**
     * FastBreak / Nuker: blok, aletine gore olmasi gereken surenin cok altinda kiriliyorsa ya da
     * kazmaya hic baslamadan kiriliyorsa log dusurur.
     */
    public static final class BreakListener implements Listener {

        private record Dig(int x, int y, int z, UUID world, long tick) {
        }

        private final BoxAC plugin;
        private final CombatListener combat;
        private final FreezeManager freeze;
        private final Map<UUID, Dig> digs = new HashMap<>();

        public BreakListener(BoxAC plugin, CombatListener combat, FreezeManager freeze) {
            this.plugin = plugin;
            this.combat = combat;
            this.freeze = freeze;
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onDamage(BlockDamageEvent e) {
            Block b = e.getBlock();
            digs.put(e.getPlayer().getUniqueId(),
                    new Dig(b.getX(), b.getY(), b.getZ(), b.getWorld().getUID(), Bukkit.getCurrentTick()));
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onBreak(BlockBreakEvent e) {
            Player p = e.getPlayer();
            Dig d = digs.remove(p.getUniqueId());

            Settings s = plugin.settings();
            if (!s.fastBreakEnabled) return;
            if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
            if (p.hasPermission("boxac.bypass")) return;
            if (freeze.isFrozen(p.getUniqueId())) return;

            Block b = e.getBlock();
            float speed = b.getBreakSpeed(p);        // tick basina ilerleme; >= 1 ise aninda kirilir
            if (speed >= 1.0f || speed <= 0f) return;
            double expected = Math.ceil(1.0 / speed);

            boolean sameBlock = d != null && d.x() == b.getX() && d.y() == b.getY() && d.z() == b.getZ()
                    && d.world().equals(b.getWorld().getUID());
            if (!sameBlock) {
                combat.flag(p, List.of(new Finding("FastBreak",
                        String.format(Locale.ROOT, "kazmaya baslamadan kirdi (Nuker?), %s, normal %.0f tick", b.getType().name(), expected))));
                return;
            }

            long elapsed = Bukkit.getCurrentTick() - d.tick();
            double needed = expected * s.fastBreakMinRatio;
            if (elapsed + s.fastBreakToleranceTicks < needed) {
                combat.flag(p, List.of(new Finding("FastBreak",
                        String.format(Locale.ROOT, "%s %d tick'te kirildi, normal %.0f tick", b.getType().name(), elapsed, expected))));
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent e) {
            digs.remove(e.getPlayer().getUniqueId());
        }
    }

    public static final class Commands implements CommandExecutor, TabCompleter {

        private final BoxAC plugin;
        private final FreezeManager freeze;

        public Commands(BoxAC plugin, FreezeManager freeze) {
            this.plugin = plugin;
            this.freeze = freeze;
        }

        @Override
        public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
            switch (cmd.getName().toLowerCase()) {
                case "freeze" -> {
                    if (a.length < 1) {
                        s.sendMessage("Kullanim: /freeze <oyuncu>");
                        return true;
                    }
                    Player t = Bukkit.getPlayerExact(a[0]);
                    if (t == null) {
                        s.sendMessage("Oyuncu cevrimici degil.");
                        return true;
                    }
                    freeze.freeze(t);
                    s.sendMessage(t.getName() + " donduruldu.");
                }
                case "unfreeze" -> {
                    if (a.length < 1) {
                        s.sendMessage("Kullanim: /unfreeze <oyuncu>");
                        return true;
                    }
                    UUID id = findId(a[0]);
                    if (id == null || !freeze.isFrozen(id)) {
                        s.sendMessage("Bu oyuncu dondurulmus degil.");
                        return true;
                    }
                    freeze.unfreeze(id);
                    s.sendMessage(a[0] + " dondurmasi kaldirildi.");
                }
                case "boxac" -> {
                    if (a.length >= 1 && a[0].equalsIgnoreCase("reload")) {
                        plugin.reloadAll();
                        s.sendMessage("BoxAC ayarlari yenilendi.");
                    } else if (a.length >= 1 && a[0].equalsIgnoreCase("list")) {
                        if (freeze.all().isEmpty()) {
                            s.sendMessage("Dondurulmus oyuncu yok.");
                        } else {
                            for (UUID id : freeze.all()) {
                                OfflinePlayer op = Bukkit.getOfflinePlayer(id);
                                s.sendMessage("- " + (op.getName() != null ? op.getName() : id.toString()));
                            }
                        }
                    } else if (a.length >= 1 && a[0].equalsIgnoreCase("setcontrol")) {
                        if (s instanceof Player pl) {
                            plugin.setControlLocation(pl.getLocation());
                            s.sendMessage("Kontrol alani bulundugun konuma ayarlandi.");
                        } else {
                            s.sendMessage("Bunu oyun icinden kullan.");
                        }
                    } else if (a.length >= 1 && a[0].equalsIgnoreCase("autofreeze")) {
                        if (a.length < 2) {
                            s.sendMessage("Otomatik dondurma su an: " + (plugin.settings().autoFreeze ? "ACIK" : "KAPALI")
                                    + "  (/boxac autofreeze <on|off>)");
                        } else if (a[1].equalsIgnoreCase("on") || a[1].equalsIgnoreCase("ac")) {
                            plugin.setAutoFreeze(true);
                            s.sendMessage("Otomatik dondurma ACILDI.");
                        } else if (a[1].equalsIgnoreCase("off") || a[1].equalsIgnoreCase("kapat")) {
                            plugin.setAutoFreeze(false);
                            s.sendMessage("Otomatik dondurma KAPATILDI. Artik sadece log + yetkili uyarisi var.");
                        } else {
                            s.sendMessage("Kullanim: /boxac autofreeze <on|off>");
                        }
                    } else if (a.length >= 1 && a[0].equalsIgnoreCase("debug")) {
                        if (a.length < 2) {
                            s.sendMessage("Debug su an: " + (plugin.settings().debug ? "ACIK" : "KAPALI") + "  (/boxac debug <on|off>)");
                        } else if (a[1].equalsIgnoreCase("on") || a[1].equalsIgnoreCase("ac")) {
                            plugin.setDebug(true);
                            s.sendMessage("Debug ACILDI: her vurus konsola yazilir.");
                        } else if (a[1].equalsIgnoreCase("off") || a[1].equalsIgnoreCase("kapat")) {
                            plugin.setDebug(false);
                            s.sendMessage("Debug KAPATILDI.");
                        } else {
                            s.sendMessage("Kullanim: /boxac debug <on|off>");
                        }
                    } else {
                        s.sendMessage("Kullanim: /boxac <reload|list|autofreeze|debug|setcontrol>");
                    }
                }
                default -> {
                }
            }
            return true;
        }

        private UUID findId(String name) {
            Player online = Bukkit.getPlayerExact(name);
            if (online != null) return online.getUniqueId();
            for (UUID id : freeze.all()) {
                OfflinePlayer op = Bukkit.getOfflinePlayer(id);
                if (op.getName() != null && op.getName().equalsIgnoreCase(name)) return id;
            }
            return null;
        }

        @Override
        public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
            List<String> out = new ArrayList<>();
            if (cmd.getName().equalsIgnoreCase("boxac") && a.length == 2 && (a[0].equalsIgnoreCase("autofreeze") || a[0].equalsIgnoreCase("debug"))) {
                for (String x : List.of("on", "off")) if (x.startsWith(a[1].toLowerCase())) out.add(x);
                return out;
            }
            if (a.length != 1) return out;
            String pre = a[0].toLowerCase();
            if (cmd.getName().equalsIgnoreCase("boxac")) {
                for (String x : List.of("reload", "list", "autofreeze", "debug", "setcontrol")) if (x.startsWith(pre)) out.add(x);
            } else if (cmd.getName().equalsIgnoreCase("unfreeze")) {
                for (UUID id : freeze.all()) {
                    String n = Bukkit.getOfflinePlayer(id).getName();
                    if (n != null && n.toLowerCase().startsWith(pre)) out.add(n);
                }
            } else {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.getName().toLowerCase().startsWith(pre)) out.add(p.getName());
                }
            }
            return out;
        }
    }
}
